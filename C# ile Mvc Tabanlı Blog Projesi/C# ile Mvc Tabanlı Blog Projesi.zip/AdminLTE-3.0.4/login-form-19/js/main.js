(function($) {

	"use strict";


})(jQuery);
